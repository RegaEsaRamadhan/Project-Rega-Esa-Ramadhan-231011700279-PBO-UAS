/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package report;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.*;
/**
 *
 * 
 */
public class CompileReport {
    public static void main(String[] args) {
        try {
            JasperCompileManager.compileReportToFile(
                "src/report/laporan_peminjaman.jrxml",
                "src/report/laporan_peminjaman.jasper"
            );
            System.out.println("✅ laporan_peminjaman.jasper berhasil dibuat.");
        } catch (JRException e) {
            e.printStackTrace();
        }
    }
}
