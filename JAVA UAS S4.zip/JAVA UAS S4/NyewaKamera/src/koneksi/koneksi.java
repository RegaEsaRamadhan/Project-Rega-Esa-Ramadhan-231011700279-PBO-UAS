package koneksi;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class koneksi {
    public static Connection getConnection() {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver"); // <- pindahkan ke sini
            String url = "jdbc:derby://localhost:1527/db_kamera";
            String user = "peminjaman";
            String pass = "123";
            return DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Koneksi gagal: " + e.getMessage());
            return null;
        }
    }
}
